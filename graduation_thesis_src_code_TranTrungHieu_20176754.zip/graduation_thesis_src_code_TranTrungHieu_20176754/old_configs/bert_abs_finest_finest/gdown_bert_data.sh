# # https://drive.google.com/file/d/1-0ETt-hN4AXZnn-cIYxg6p80LkbqH4iu/view?usp=sharing
# gdown --id 1-0ETt-hN4AXZnn-cIYxg6p80LkbqH4iu
# unzip ./multi_news_bert_led_shards.zip


# https://drive.google.com/file/d/1-A_6QnYDMUGG4nqmM6I8GrjALc1CHbBl/view?usp=sharing

gdown --id 1-A_6QnYDMUGG4nqmM6I8GrjALc1CHbBl
unzip ./abs_bert_data_shards.zip

# # https://drive.google.com/file/d/1-GnBGD1VfOR1gqa7b7jP7ok4j4h18lBd/view?usp=sharing
# gdown --id 1-GnBGD1VfOR1gqa7b7jP7ok4j4h18lBd
# unzip ./abs_bert_data_shards_filtered.zip