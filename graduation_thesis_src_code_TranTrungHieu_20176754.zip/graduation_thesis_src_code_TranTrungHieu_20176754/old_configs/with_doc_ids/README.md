
1 ROUGE-1 Average_R: 0.44490 (95%-conf.int. 0.44170 - 0.44782)
1 ROUGE-1 Average_P: 0.46476 (95%-conf.int. 0.46165 - 0.46808)
1 ROUGE-1 Average_F: 0.43937 (95%-conf.int. 0.43700 - 0.44172)
---------------------------------------------
1 ROUGE-2 Average_R: 0.15436 (95%-conf.int. 0.15175 - 0.15714)
1 ROUGE-2 Average_P: 0.15994 (95%-conf.int. 0.15716 - 0.16283)
1 ROUGE-2 Average_F: 0.15192 (95%-conf.int. 0.14934 - 0.15450)
---------------------------------------------
1 ROUGE-L Average_R: 0.40539 (95%-conf.int. 0.40240 - 0.40813)
1 ROUGE-L Average_P: 0.42486 (95%-conf.int. 0.42184 - 0.42806)
1 ROUGE-L Average_F: 0.40104 (95%-conf.int. 0.39863 - 0.40345)

[2022-05-25 16:44:10,098 INFO] Rouges at step 10000 
>> ROUGE-F(1/2/3/l): 43.94/15.19/40.10
ROUGE-R(1/2/3/l): 44.49/15.44/40.54



10k , 12k , 8k