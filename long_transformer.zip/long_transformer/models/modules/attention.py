from ast import Global
import torch 
import torch.nn as nn 
from typing import List, Optional, Text, Tuple


class GlobalAttention(nn.Module):
    def __init__(self, ):
        super(GlobalAttention, self).__init__()

    def forward(self, ):
        return

class RelativeAttention(nn.Module):
    def __init__(self, ):
        super(RelativeAttention, self).__init__()


    def forward(self, ):
        return 



class FusedGlobalLocalAttention(nn.Module):
    def __init__(self, ):
        super(FusedGlobalLocalAttention, self).__init__()


    def forward(self, ):
        return 

class ProjectAttentionHeads(nn.Module):
    def __init__(self, ):
        super(ProjectAttentionHeads, self).__init__()


    def forward(self, ):
        return 

class QkvRelativeAttention(nn.Module):
    def __init__(self, ):
        super(QkvRelativeAttention, self).__init__()


    def forward(self, ):
        return 

class QkvRelativeLocalAttention(nn.Module):
    def __init__(self, ):
        super(QkvRelativeLocalAttention, self).__init__()


    def forward(self, ):
        return 