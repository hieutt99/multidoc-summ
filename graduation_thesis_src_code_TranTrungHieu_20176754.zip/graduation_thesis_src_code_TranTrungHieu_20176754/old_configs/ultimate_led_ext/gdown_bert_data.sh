# https://drive.google.com/file/d/1-0ETt-hN4AXZnn-cIYxg6p80LkbqH4iu/view?usp=sharing



# https://drive.google.com/file/d/1-81tUKva0b6qe4TZu-v_SgcHz5Brv_z9/view?usp=sharing
gdown --id 1-81tUKva0b6qe4TZu-v_SgcHz5Brv_z9
unzip ./multi_news_bert_led_ext_shards.zip

# https://drive.google.com/file/d/1-4Ou95GY8jb3R12dmN320NMOWux0xviY/view?usp=sharing

# gdown --id 1-4Ou95GY8jb3R12dmN320NMOWux0xviY
# unzip ./multi_news_bert_led_ext_shards_5.zip
# mv multi_news_bert_led_ext_shards_5 multi_news_bert_led_ext_shards