# https://drive.google.com/file/d/1-07IHGFpfG-1Ulim9jQvrNhmuWUfKsH4/view?usp=sharing
gdown --id 1-07IHGFpfG-1Ulim9jQvrNhmuWUfKsH4
unzip ./vietnews_bert_data_shards.zip